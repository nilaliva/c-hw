﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Windows.Input;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Sklad_tr.Commands;

namespace Sklad_tr.ViewModels
{
    public class RegistrationViewModel : INotifyPropertyChanged
    {
        private string _username;
        private string _password;
        private ICommand _registerCommand;

        public string Username
        {
            get { return _username; }
            set { _username = value; OnPropertyChanged(); }
        }

        public string Password
        {
            get { return _password; }
            set { _password = value; OnPropertyChanged(); }
        }

        public ICommand RegisterCommand
        {
            get
            {
                if (_registerCommand == null)
                    _registerCommand = new RelayCommand(Register, CanRegister);
                return _registerCommand;
            }
        }

        private bool CanRegister(object parameter)
        {
            return !string.IsNullOrEmpty(_username) && !string.IsNullOrEmpty(_password);
        }

        private void Register(object parameter)
        {
            Console.WriteLine($"Registering user: Username - {_username}, Password - {_password}");
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}