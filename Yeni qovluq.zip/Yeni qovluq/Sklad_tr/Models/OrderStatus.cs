﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sklad_tr.Models
{
    public class OrderStatus
    {
        public int OrderStatusId { get; set; }
        public string Status { get; set; }
    }
}
